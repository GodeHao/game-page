# 星海谣 Starlight Bloom —— AI 快速启动指南（必读）

> 本机每次开机/重置后会删除 `node_modules` 与 `target` 文件夹。
> **不要重新推理架构，直接按本文件 + `start.bat` 启动即可。**

## 一、项目组成与固定路径（绝对路径，勿改）

| 角色 | 路径 | 说明 |
|------|------|------|
| 前端 Vue3+Vite | `C:\Users\Administrator\Desktop\starlight-vue` | dev 端口 5173 |
| 后端 SpringBoot | `D:\workSpace\springBootTest` | 端口 8081（见下方坑位） |
| SQL / 测试脚本 | `D:\workSpace\springBootTest\sql\starlight_bloom.sql` | 数据库初始化 |

- 数据库：`starlight_bloom`（MySQL 8.0，root / 123456，端口 3306，服务已在运行）
- 后端技术：SpringBoot 3.4.5 + MyBatis-Plus 3.5.7 + MySQL 驱动 + WebSocket + Lombok，Java 17（本机 JDK 21 可编译）
- 前端技术：Vue3 + Vite 6 + vue-router + axios

## 二、⚠️ 三个必踩的坑（已解决，勿重复排查）

1. **端口被环境变量覆盖**：WorkBuddy 注入了环境变量 `SERVER__PORT=55233`，
   Spring Boot 会把它映射成 `server.port`，导致后端起在 55233 而非 8081。
   **解决**：启动后端时必须显式设置 `set SERVER__PORT=8081`（start.bat 已处理）。
2. **Maven 不在 PATH**：本机没有全局 mvn。用后端目录下的 `mvnw.cmd` 打包
   （它会下载 Maven 3.9.9 到用户目录，首次约 30 秒）。
   **不要用 Git Bash 调 `./mvnw`**（路径转换会失败），用 `mvnw.cmd`。
3. **CORS**：Controller 上不要加 `@CrossOrigin(origins="*")`，会与全局
   `CorsConfig`（allowCredentials + allowedOriginPatterns）冲突报错。已在代码中移除。

## 三、一键启动（重置后）

双击桌面 `starlight-vue\start.bat`（或在目录里运行）。它会：
1. 检查并导入数据库（若 `starlight_bloom` 不存在则导入 SQL）
2. 前端：`npm install`（重建 node_modules）
3. 后端：`mvnw.cmd clean package -DskipTests`（重建 target）
4. 设置 `SERVER__PORT=8081` 后启动后端
5. 启动前端 dev server

停止：运行 `stop.bat`（按端口杀掉 8081 / 5173 进程）。

## 四、局域网访问

- 本机局域网 IP：**192.168.68.48**（如变化，用 `ipconfig` 查以太网 IPv4）
- 局域网设备访问前端：`http://192.168.68.48:5173`
- 前端 dev server 监听 `0.0.0.0`，`/api` 与 `/ws` 代理到后端，因此局域网设备
  访问前端即可间接访问后端，无需单独暴露后端端口。
- 后端 `server.address=0.0.0.0` 也已监听所有网卡。

## 五、账号

| 账号 | 密码 | 权限 | 用途 |
|------|------|------|------|
| admin | admin123 | 0=管理员 | 后台管理系统（首页导航栏可见“后台管理”按钮） |
| xingke | 123456 | 1=普通用户 | 测试用户（拍卖行出价等） |

- 注册：QQ 邮箱（qq.com / vip.qq.com / foxmail.com），密码明文存库（流程要求），初始 1000 灵石
- 权限字段 `t_user.permission`：1=普通用户，0=管理员

## 六、接口清单

- `POST /api/auth/register`  注册
- `POST /api/auth/login`  登录（返回 token + user，含 permission/stones）
- `GET  /api/items?keyword=&type=&grade=`  首页搜索/分级分类
- `GET  /api/items/{id}`  物品详情
- `GET  /api/admin/items`  后台列表（需管理员 token）
- `POST /api/admin/items`  新增（需管理员 token）
- `PUT  /api/admin/items`  更新（需管理员 token）
- `DELETE /api/admin/items/{id}`  删除（需管理员 token）
- `WS   /ws/auction`  拍卖行实时通信

## 七、拍卖行规则（已在 AuctionEngine 实现）

- 每 10 分钟一场，开拍前 60 秒广播 notice
- 每场从 `auction_flag=0` 的物品按品级 凡<灵<玄<地<天 取 5 件
- 起拍价 100 灵石，加价档 10/50/100/500，加价后 5 秒倒计时重置
- 落槌归最高出价者，扣灵石，物品 auction_flag 置 1
- 管理员可在拍卖页点“立即开拍(演示)”触发（WS forceStart）
- 已用 Python websocket-client 端到端测试通过（见 sql/ws_test.py）

## 八、验证状态（2026-11-20）

- 前端 `npm run build` 通过
- 后端 `mvnw.cmd package` 通过
- 注册/登录/搜索/管理员 CRUD 接口 curl 测试通过
- 拍卖行 WebSocket 端到端测试 PASS（roundStart/bid/lotEnd/扣款/在线人数）
