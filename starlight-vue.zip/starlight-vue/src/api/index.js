import axios from 'axios'

// 统一走 /api 代理；WebSocket 单独在拍卖页处理
const api = axios.create({
  baseURL: '/api',
  timeout: 15000
})

api.interceptors.request.use(config => {
  const token = localStorage.getItem('sl_token')
  if (token) config.headers['Authorization'] = 'Bearer ' + token
  return config
})

api.interceptors.response.use(
  res => {
    const body = res.data
    // 后端统一 Result: {code, message, data}
    if (body && typeof body === 'object' && 'code' in body) {
      if (body.code === 0) return body.data
      return Promise.reject(new Error(body.message || '请求失败'))
    }
    return body
  },
  err => {
    const d = err.response?.data
    const msg = (d && d.message) || (typeof d === 'string' ? d : null) || err.message || '请求失败'
    return Promise.reject(new Error(msg))
  }
)

export default api
