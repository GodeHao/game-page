<template>
  <canvas ref="cv" id="sky-canvas"></canvas>
</template>

<script setup>
import { onMounted, onBeforeUnmount, ref } from 'vue'

const cv = ref(null)
let ctx, raf, stars = [], shooting = [], W = 0, H = 0, dpr = 1

function resize() {
  const c = cv.value
  dpr = Math.min(window.devicePixelRatio || 1, 2)
  W = window.innerWidth
  H = window.innerHeight
  c.width = W * dpr
  c.height = H * dpr
  c.style.width = W + 'px'
  c.style.height = H + 'px'
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
  initStars()
}

function initStars() {
  const count = Math.min(260, Math.floor(W * H / 6000))
  stars = Array.from({ length: count }, () => ({
    x: Math.random() * W,
    y: Math.random() * H,
    r: Math.random() * 1.4 + 0.3,
    a: Math.random(),
    speed: Math.random() * 0.02 + 0.005,
    hue: Math.random() > 0.7 ? (Math.random() > 0.5 ? '169,240,255' : '255,183,229') : '255,255,255'
  }))
}

function maybeShooting() {
  if (Math.random() < 0.006 && shooting.length < 2) {
    shooting.push({ x: Math.random() * W, y: Math.random() * H * 0.4, len: 90 + Math.random() * 80, life: 1 })
  }
}

function frame() {
  ctx.clearRect(0, 0, W, H)
  for (const s of stars) {
    s.a += s.speed
    const alpha = 0.35 + Math.abs(Math.sin(s.a)) * 0.55
    ctx.beginPath()
    ctx.fillStyle = `rgba(${s.hue},${alpha})`
    ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2)
    ctx.fill()
  }
  maybeShooting()
  shooting = shooting.filter(sh => sh.life > 0)
  for (const sh of shooting) {
    const g = ctx.createLinearGradient(sh.x, sh.y, sh.x - sh.len, sh.y + sh.len * 0.5)
    g.addColorStop(0, `rgba(255,255,255,${sh.life})`)
    g.addColorStop(1, 'rgba(255,255,255,0)')
    ctx.strokeStyle = g
    ctx.lineWidth = 1.6
    ctx.beginPath()
    ctx.moveTo(sh.x, sh.y)
    ctx.lineTo(sh.x - sh.len, sh.y + sh.len * 0.5)
    ctx.stroke()
    sh.x -= 6; sh.y += 3; sh.life -= 0.02
  }
  raf = requestAnimationFrame(frame)
}

onMounted(() => {
  ctx = cv.value.getContext('2d')
  resize()
  window.addEventListener('resize', resize)
  frame()
})
onBeforeUnmount(() => {
  cancelAnimationFrame(raf)
  window.removeEventListener('resize', resize)
})
</script>

<style scoped>
#sky-canvas { position: fixed; }
</style>
