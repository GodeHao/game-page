import { createRouter, createWebHistory } from 'vue-router'

// 从 localStorage 读取当前登录用户
function currentUser() {
  try { return JSON.parse(localStorage.getItem('sl_user') || 'null') } catch { return null }
}

const routes = [
  { path: '/', redirect: '/login' },
  {
    path: '/login',
    name: 'login',
    component: () => import('../views/Login.vue'),
    meta: { public: true }
  },
  {
    path: '/register',
    name: 'register',
    component: () => import('../views/Register.vue'),
    meta: { public: true }
  },
  {
    path: '/home',
    name: 'home',
    component: () => import('../views/Home.vue')
  },
  {
    path: '/auction',
    name: 'auction',
    component: () => import('../views/Auction.vue')
  },
  {
    path: '/admin-login',
    name: 'admin-login',
    component: () => import('../views/AdminLogin.vue'),
    meta: { public: true }
  },
  {
    path: '/admin',
    name: 'admin',
    component: () => import('../views/Admin.vue'),
    meta: { adminOnly: true }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  const user = currentUser()
  if (to.meta.adminOnly) {
    if (!user || user.permission !== 0) {
      return next({ name: 'admin-login' })
    }
  }
  if (!to.meta.public && !user) {
    return next({ name: 'login' })
  }
  next()
})

export default router
