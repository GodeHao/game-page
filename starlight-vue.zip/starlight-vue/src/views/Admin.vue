<template>
  <div class="screen admin-page">
    <Starfield />
    <nav class="nav-bar">
      <div class="nav-brand"><span class="logo">⚙</span><span class="grad-text">星域控制台</span></div>
      <div class="nav-links">
        <button @click="$router.push('/home')">返回宝阁</button>
        <button @click="$router.push('/auction')">拍卖行</button>
      </div>
      <div class="nav-user"><span class="chip">管理员</span><button class="btn-ghost" @click="logout">退出</button></div>
    </nav>

    <main class="content">
      <div class="head">
        <h2 class="grad-text">数据管理</h2>
        <button class="btn-ghost add" @click="openNew">+ 新增宝物</button>
      </div>

      <div class="table-wrap glass">
        <table>
          <thead>
            <tr><th>ID</th><th>名称</th><th>类别</th><th>品级</th><th>价格</th><th>拍卖</th><th>操作</th></tr>
          </thead>
          <tbody>
            <tr v-for="it in items" :key="it.id">
              <td>{{ it.id }}</td>
              <td>{{ it.name }}</td>
              <td>{{ it.type }}</td>
              <td :class="'grade-' + it.grade">{{ it.grade }}</td>
              <td>{{ it.price ?? '-' }}</td>
              <td>{{ it.auctionFlag === 1 ? '是' : '否' }}</td>
              <td class="ops">
                <button @click="openEdit(it)">编辑</button>
                <button class="del" @click="remove(it)">删除</button>
              </td>
            </tr>
          </tbody>
        </table>
        <div v-if="!items.length" class="empty">暂无数据，点击右上角新增</div>
      </div>
    </main>

    <!-- 编辑 / 新增弹窗 -->
    <transition name="fade">
      <div v-if="editing" class="modal-mask" @click.self="editing = null">
        <div class="modal glass">
          <button class="modal-x" @click="editing = null">×</button>
          <h2 class="grad-text">{{ form.id ? '编辑宝物' : '新增宝物' }}</h2>
          <div class="form-grid">
            <label>名称<input v-model="form.name" placeholder="宝物名称"></label>
            <label>类别<select v-model="form.type"><option>功法</option><option>法宝</option><option>丹药</option></select></label>
            <label>品级<select v-model="form.grade"><option>凡</option><option>灵</option><option>玄</option><option>地</option><option>天</option></select></label>
            <label>价格<input v-model.number="form.price" type="number" min="0" placeholder="灵石"></label>
            <label>拍卖<select v-model.number="form.auctionFlag"><option :value="0">未拍卖</option><option :value="1">拍卖</option></select></label>
            <label class="full">描述<textarea v-model="form.description" rows="3" placeholder="宝物描述 / 属性"></textarea></label>
          </div>
          <p class="tip">{{ tip }}</p>
          <button class="btn-main" @click="save">保 存</button>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import api from '../api'
import Starfield from '../components/Starfield.vue'

const router = useRouter()
const items = ref([])
const editing = ref(false)
const tip = ref('')
const form = reactive({ id: null, name: '', type: '功法', grade: '凡', price: 0, auctionFlag: 0, description: '' })

async function load() {
  try { items.value = await api.get('/admin/items') }
  catch (e) { console.warn(e.message) }
}
function openNew() {
  Object.assign(form, { id: null, name: '', type: '功法', grade: '凡', price: 0, auctionFlag: 0, description: '' })
  tip.value = ''; editing.value = true
}
function openEdit(it) { Object.assign(form, it); tip.value = ''; editing.value = true }

async function save() {
  if (!form.name.trim()) return void (tip.value = '请输入名称')
  try {
    if (form.id) await api.put('/admin/items', form)
    else await api.post('/admin/items', form)
    editing.value = false
    load()
  } catch (e) { tip.value = e.message }
}
async function remove(it) {
  if (!confirm(`确定删除「${it.name}」？`)) return
  try { await api.delete('/admin/items/' + it.id); load() }
  catch (e) { alert(e.message) }
}
function logout() {
  localStorage.removeItem('sl_token'); localStorage.removeItem('sl_user')
  router.push('/admin-login')
}
onMounted(load)
</script>

<style scoped>
.content { max-width: 1100px; margin: 0 auto; padding: 30px 24px 60px; }
.logo { color: var(--star-gold); font-size: 20px; }
.head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.head h2 { font-size: 24px; letter-spacing: 4px; margin: 0; }
.table-wrap { overflow-x: auto; padding: 10px; }
table { width: 100%; border-collapse: collapse; font-size: 14px; }
th, td { padding: 12px 14px; text-align: left; border-bottom: 1px solid var(--glass-line); white-space: nowrap; }
th { color: var(--star-cyan); font-weight: 600; }
.ops button { border: none; background: rgba(169,240,255,.12); color: var(--ink); padding: 5px 12px; border-radius: 8px; margin-right: 6px; }
.ops button.del { background: rgba(255,150,170,.14); }
.grade-凡 { color: #b9c4d6; } .grade-灵 { color: #7fe3c0; } .grade-玄 { color: #7fb8ff; } .grade-地 { color: #c79bff; } .grade-天 { color: #ffcf7f; }

.modal-mask { position: fixed; inset: 0; z-index: 50; background: rgba(3,6,20,.7); display: flex; align-items: center; justify-content: center; padding: 20px; }
.modal { width: 100%; max-width: 520px; padding: 28px; position: relative; }
.modal-x { position: absolute; top: 10px; right: 16px; border: none; background: transparent; color: var(--ink-soft); font-size: 24px; }
.modal h2 { margin: 0 0 18px; }
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
.form-grid label { display: flex; flex-direction: column; gap: 6px; font-size: 13px; color: var(--ink-soft); }
.form-grid .full { grid-column: 1 / -1; }
.form-grid input, .form-grid select, .form-grid textarea {
  padding: 10px 12px; border-radius: 10px; border: 1px solid var(--glass-line);
  background: rgba(8,12,32,.6); color: var(--ink); outline: none; resize: vertical;
}
.form-grid input:focus, .form-grid select:focus, .form-grid textarea:focus { border-color: var(--star-cyan); }
.modal .btn-main { margin-top: 8px; }
.fade-enter-active, .fade-leave-active { transition: opacity .2s; }
.fade-enter-from, .fade-leave-to { opacity: 0; }
</style>
