<template>
  <div class="screen auth-page">
    <Starfield />
    <div class="auth-wrap">
      <div class="brand">
        <div class="brand-mark">⚙</div>
        <h1 class="brand-title grad-text">星域控制台</h1>
        <p class="brand-sub">Admin Console · 仅管理员可进入</p>
      </div>
      <div class="auth-card glass">
        <h2 class="card-title">管理员登录</h2>
        <form class="auth-form" @submit.prevent="onLogin" autocomplete="off" novalidate>
          <div class="field">
            <span class="field-icon">✦</span>
            <input v-model="username" placeholder="管理员账号" maxlength="30">
          </div>
          <div class="field">
            <span class="field-icon">✧</span>
            <input type="password" v-model="password" placeholder="密码" maxlength="40">
          </div>
          <p class="tip" :class="{ ok: tipOk }">{{ tip }}</p>
          <button type="submit" class="btn-main" :disabled="loading">{{ loading ? '验证中…' : '进入控制台' }}</button>
        </form>
        <div class="foot"><router-link to="/home">← 返回星域宝阁</router-link></div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import api from '../api'
import Starfield from '../components/Starfield.vue'

const router = useRouter()
const username = ref('')
const password = ref('')
const tip = ref('')
const tipOk = ref(false)
const loading = ref(false)

async function onLogin() {
  tip.value = ''
  loading.value = true
  try {
    const res = await api.post('/auth/login', { username: username.value.trim(), password: password.value })
    if (res.user.permission !== 0) throw new Error('该账号不是管理员，无权进入控制台')
    localStorage.setItem('sl_token', res.token || '')
    localStorage.setItem('sl_user', JSON.stringify(res.user))
    tip.value = '验证通过，正在进入…'
    tipOk.value = true
    setTimeout(() => router.push('/admin'), 400)
  } catch (e) {
    tip.value = e.message || '登录失败'
    tipOk.value = false
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.auth-page { display: flex; align-items: center; justify-content: center; padding: 40px 16px; }
.auth-wrap { width: 100%; max-width: 400px; }
.brand { text-align: center; margin-bottom: 24px; }
.brand-mark { font-size: 40px; color: var(--star-gold); }
.brand-title { font-size: 32px; letter-spacing: 6px; margin: 6px 0 2px; }
.brand-sub { color: var(--ink-soft); font-size: 12px; margin: 0; }
.auth-card { padding: 28px; }
.card-title { text-align: center; letter-spacing: 3px; margin: 0 0 22px; font-size: 17px; }
.auth-form { display: flex; flex-direction: column; gap: 14px; }
.foot { margin-top: 16px; text-align: center; font-size: 13px; }
</style>
