<template>
  <div class="screen home-page">
    <Starfield />

    <!-- 导航栏 -->
    <nav class="nav-bar">
      <div class="nav-brand">
        <span class="logo">✦</span>
        <span class="grad-text">星海谣</span>
      </div>
      <div class="nav-links">
        <button class="active" @click="$router.push('/home')">星域宝阁</button>
        <button @click="$router.push('/auction')">拍卖行</button>
        <button v-if="isAdmin" @click="$router.push('/admin')">后台管理</button>
      </div>
      <div class="nav-user">
        <span class="avatar">{{ (user.username || '星')[0].toUpperCase() }}</span>
        <span>{{ user.username }}</span>
        <span class="chip">💎 {{ stones }} 灵石</span>
        <button class="btn-ghost" @click="logout">退出</button>
      </div>
    </nav>

    <main class="content">
      <!-- 头部标语 + 搜索栏 -->
      <header class="hero">
        <h1 class="grad-text">拾 星 者 的 宝 阁</h1>
        <p>功法 · 法宝 · 丹药，皆藏于星海之间</p>
        <div class="search-row">
          <div class="search-box">
            <span class="field-icon">⌕</span>
            <input v-model="keyword" @keyup.enter="doSearch" placeholder="搜索功法、法宝、丹药…">
            <button class="search-btn" @click="doSearch">搜 索</button>
          </div>
        </div>
        <div class="filters">
          <button v-for="t in types" :key="t" :class="['filter', { on: activeType === t }]" @click="pickType(t)">
            {{ t }}
          </button>
          <span class="filter-sep"></span>
          <button v-for="g in grades" :key="g" :class="['filter', 'grade-' + g, { on: activeGrade === g }]" @click="pickGrade(g)">
            {{ g }}
          </button>
        </div>
      </header>

      <!-- 物品网格 -->
      <section v-if="items.length" class="grid">
        <article v-for="it in items" :key="it.id" class="item-card glass">
          <div class="item-badge" :class="'grade-' + it.grade">{{ it.grade }}</div>
          <div class="item-icon">{{ iconFor(it.type) }}</div>
          <h3>{{ it.name }}</h3>
          <div class="meta">
            <span class="chip">{{ it.type }}</span>
            <span class="auction-flag" :class="{ on: it.auctionFlag === 1 }">
              {{ it.auctionFlag === 1 ? '拍卖中' : '未拍卖' }}
            </span>
          </div>
          <p class="desc">{{ it.description || '星光黯淡，暂无描述。' }}</p>
          <div class="card-foot">
            <span class="price">💎 {{ it.price != null ? it.price + ' 灵石' : '无价' }}</span>
            <button class="btn-ghost" @click="openDetail(it)">查看属性</button>
          </div>
        </article>
      </section>
      <div v-else class="empty glass">星海中未寻得符合条件的宝物 ✧</div>
    </main>

    <!-- 属性详情弹窗 -->
    <transition name="fade">
      <div v-if="detail" class="modal-mask" @click.self="detail = null">
        <div class="modal glass">
          <button class="modal-x" @click="detail = null">×</button>
          <div class="modal-icon">{{ iconFor(detail.type) }}</div>
          <h2 class="grad-text">{{ detail.name }}</h2>
          <div class="meta" style="justify-content:center">
            <span class="chip">{{ detail.type }}</span>
            <span class="chip grade-chip" :class="'grade-' + detail.grade">{{ detail.grade }}品</span>
          </div>
          <div class="attr-list">
            <div class="attr"><span>品级</span><b>{{ detail.grade }}</b></div>
            <div class="attr"><span>类别</span><b>{{ detail.type }}</b></div>
            <div class="attr"><span>价格</span><b>{{ detail.price != null ? detail.price + ' 灵石' : '无价' }}</b></div>
            <div class="attr"><span>状态</span><b>{{ detail.auctionFlag === 1 ? '拍卖中' : '未拍卖' }}</b></div>
          </div>
          <p class="desc" style="text-align:center">{{ detail.description || '暂无描述。' }}</p>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import api from '../api'
import Starfield from '../components/Starfield.vue'

const router = useRouter()
const user = computed(() => { try { return JSON.parse(localStorage.getItem('sl_user') || '{}') } catch { return {} } })
const isAdmin = computed(() => user.value.permission === 0)
const stones = ref(user.value.stones ?? 0)

const keyword = ref('')
const activeType = ref('全部')
const activeGrade = ref('全部')
const types = ['全部', '功法', '法宝', '丹药']
const grades = ['全部', '凡', '灵', '玄', '地', '天']
const items = ref([])
const detail = ref(null)

function iconFor(type) {
  return { 功法: '📜', 法宝: '🔮', 丹药: '💊' }[type] || '✦'
}

async function load() {
  try {
    const params = {}
    if (keyword.value.trim()) params.keyword = keyword.value.trim()
    if (activeType.value !== '全部') params.type = activeType.value
    if (activeGrade.value !== '全部') params.grade = activeGrade.value
    items.value = await api.get('/items', { params })
  } catch (e) {
    items.value = []
    console.warn('加载宝阁失败:', e.message)
  }
}

function doSearch() { load() }
function pickType(t) { activeType.value = t; load() }
function pickGrade(g) { activeGrade.value = g; load() }
function openDetail(it) { detail.value = it }
function logout() {
  localStorage.removeItem('sl_token')
  localStorage.removeItem('sl_user')
  router.push('/login')
}

onMounted(load)
</script>

<style scoped>
.content { max-width: 1200px; margin: 0 auto; padding: 30px 24px 60px; }
.logo { color: var(--star-cyan); font-size: 22px; }
.hero { text-align: center; padding: 22px 0 30px; }
.hero h1 { font-size: 34px; letter-spacing: 10px; margin: 0 0 8px; }
.hero p { color: var(--ink-soft); margin: 0 0 24px; letter-spacing: 2px; }
.search-row { display: flex; justify-content: center; }
.search-box {
  display: flex; align-items: center; gap: 10px; width: 100%; max-width: 620px;
  padding: 8px 8px 8px 16px; border-radius: 14px;
  border: 1px solid var(--glass-line); background: rgba(8,12,32,.55);
}
.search-box input { flex: 1; border: none; outline: none; background: transparent; color: var(--ink); font-size: 15px; }
.search-btn { padding: 10px 22px; border: none; border-radius: 10px; color: #0a1030; font-weight: 600; background: var(--accent); }
.filters { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; margin-top: 20px; }
.filter { padding: 7px 16px; border-radius: 999px; border: 1px solid var(--glass-line); background: rgba(255,255,255,.03); color: var(--ink-soft); font-size: 13px; transition: all .2s; }
.filter:hover, .filter.on { color: var(--ink); background: rgba(169,240,255,.14); border-color: var(--star-cyan); }
.filter-sep { width: 1px; background: var(--glass-line); margin: 4px 6px; }
.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 18px; }
.item-card { padding: 20px; position: relative; transition: transform .2s; }
.item-card:hover { transform: translateY(-4px); }
.item-badge { position: absolute; top: 14px; right: 14px; font-size: 11px; padding: 2px 9px; border-radius: 999px; border: 1px solid currentColor; }
.item-icon { font-size: 40px; text-align: center; margin: 6px 0 10px; filter: drop-shadow(0 0 12px rgba(169,240,255,.4)); }
.item-card h3 { margin: 0 0 10px; font-size: 17px; }
.meta { display: flex; gap: 8px; align-items: center; margin-bottom: 8px; }
.auction-flag { font-size: 12px; color: var(--ink-soft); }
.auction-flag.on { color: var(--star-pink); }
.desc { color: var(--ink-soft); font-size: 13px; line-height: 1.6; min-height: 42px; }
.card-foot { display: flex; justify-content: space-between; align-items: center; margin-top: 12px; }
.price { color: var(--star-gold); font-size: 13px; }

/* 品级配色 */
.grade-凡 { color: #b9c4d6; } .grade-灵 { color: #7fe3c0; }
.grade-玄 { color: #7fb8ff; } .grade-地 { color: #c79bff; } .grade-天 { color: #ffcf7f; }

/* 弹窗 */
.modal-mask { position: fixed; inset: 0; z-index: 50; background: rgba(3,6,20,.7); display: flex; align-items: center; justify-content: center; padding: 20px; backdrop-filter: blur(4px); }
.modal { width: 100%; max-width: 400px; padding: 30px; text-align: center; position: relative; }
.modal-x { position: absolute; top: 12px; right: 16px; border: none; background: transparent; color: var(--ink-soft); font-size: 24px; }
.modal-icon { font-size: 56px; margin-bottom: 8px; }
.modal h2 { margin: 4px 0 12px; font-size: 24px; }
.attr-list { margin: 18px 0; border-top: 1px solid var(--glass-line); border-bottom: 1px solid var(--glass-line); }
.attr { display: flex; justify-content: space-between; padding: 9px 4px; font-size: 14px; }
.attr span { color: var(--ink-soft); }
.fade-enter-active, .fade-leave-active { transition: opacity .2s; }
.fade-enter-from, .fade-leave-to { opacity: 0; }
</style>
