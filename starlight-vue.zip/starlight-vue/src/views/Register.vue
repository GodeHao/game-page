<template>
  <div class="screen auth-page">
    <Starfield />
    <div class="auth-wrap">
      <div class="brand">
        <div class="brand-mark">✦</div>
        <h1 class="brand-title grad-text">缔造星籍</h1>
        <p class="brand-sub">Register · 开启你的星海航程</p>
      </div>

      <div class="auth-card glass">
        <div class="tab-bar">
          <router-link to="/login" class="tab">登 录</router-link>
          <span class="tab active">注 册</span>
        </div>
        <form class="auth-form" @submit.prevent="onRegister" autocomplete="off" novalidate>
          <div class="field">
            <span class="field-icon">✦</span>
            <input v-model="form.username" placeholder="星空账号（用作登录）" maxlength="30">
          </div>
          <div class="field">
            <span class="field-icon">✉</span>
            <input v-model="form.email" placeholder="QQ 邮箱（如 123456@qq.com）" maxlength="40">
          </div>
          <div class="field">
            <span class="field-icon">✧</span>
            <input :type="showPwd ? 'text' : 'password'" v-model="form.password" placeholder="密码（至少 6 位）" maxlength="40">
            <button type="button" class="eye" @click="showPwd = !showPwd">{{ showPwd ? '◌' : '◉' }}</button>
          </div>
          <div class="field">
            <span class="field-icon">✧</span>
            <input :type="showPwd ? 'text' : 'password'" v-model="form.confirm" placeholder="确认密码" maxlength="40">
          </div>
          <p class="tip" :class="{ ok: tipOk }">{{ tip }}</p>
          <button type="submit" class="btn-main" :disabled="loading">{{ loading ? '缔造中…' : '缔 造 · 注册' }}</button>
        </form>
        <div class="foot">
          <span>已有星籍？</span>
          <router-link to="/login">返回登录 →</router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import api from '../api'
import Starfield from '../components/Starfield.vue'

const router = useRouter()
const form = reactive({ username: '', email: '', password: '', confirm: '' })
const showPwd = ref(false)
const tip = ref('')
const tipOk = ref(false)
const loading = ref(false)

async function onRegister() {
  tip.value = ''
  if (!form.username.trim()) return void (tip.value = '请输入星空账号')
  if (!/^\S+@(qq\.com|vip\.qq\.com|foxmail\.com)$/i.test(form.email.trim()))
    return void (tip.value = '邮箱需为 QQ 邮箱（qq.com / vip.qq.com / foxmail.com）')
  if (form.password.length < 6) return void (tip.value = '密码至少 6 位')
  if (form.password !== form.confirm) return void (tip.value = '两次密码不一致')

  loading.value = true
  try {
    await api.post('/auth/register', {
      username: form.username.trim(),
      email: form.email.trim(),
      password: form.password
    })
    tip.value = '注册成功，正在前往登录…'
    tipOk.value = true
    setTimeout(() => router.push('/login'), 700)
  } catch (e) {
    tip.value = e.message || '注册失败'
    tipOk.value = false
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.auth-page { display: flex; align-items: center; justify-content: center; padding: 40px 16px; }
.auth-wrap { width: 100%; max-width: 440px; }
.brand { text-align: center; margin-bottom: 24px; }
.brand-mark { font-size: 42px; color: var(--star-cyan); filter: drop-shadow(0 0 14px rgba(169,240,255,.6)); }
.brand-title { font-size: 34px; letter-spacing: 8px; margin: 6px 0 2px; }
.brand-sub { color: var(--ink-soft); font-size: 13px; margin: 0; letter-spacing: 1px; }
.auth-card { padding: 26px 28px 22px; }
.tab-bar { display: flex; gap: 22px; border-bottom: 1px solid var(--glass-line); margin-bottom: 20px; }
.tab { padding: 8px 2px 12px; font-size: 15px; color: var(--ink-soft); letter-spacing: 2px; }
.tab.active { color: var(--star-cyan); border-bottom: 2px solid var(--star-cyan); }
.auth-form { display: flex; flex-direction: column; gap: 12px; }
.eye { border: none; background: transparent; color: var(--star-cyan); font-size: 16px; }
.foot { margin-top: 16px; text-align: center; font-size: 13px; color: var(--ink-soft); }
.foot a { margin-left: 6px; }
</style>
