<template>
  <div class="screen auction-page">
    <Starfield />
    <nav class="nav-bar">
      <div class="nav-brand"><span class="logo">⚖</span><span class="grad-text">星域拍卖行</span></div>
      <div class="nav-links">
        <button @click="$router.push('/home')">返回宝阁</button>
        <button class="active">拍卖行</button>
        <button v-if="isAdmin" @click="$router.push('/admin')">后台管理</button>
      </div>
      <div class="nav-user">
        <span class="chip">🟢 在线 {{ online }}</span>
        <span class="chip">💎 {{ stones }} 灵石</span>
      </div>
    </nav>

    <main class="content">
      <!-- 状态条 -->
      <div class="status-bar glass">
        <span v-if="notice" class="notice">🔔 {{ notice }}</span>
        <span v-else-if="phase === 'idle'" class="idle">拍卖行休市中，每 10 分钟开启一场 · 下一场倒计时 {{ nextIn }}s</span>
        <span v-else-if="phase === 'bidding'">拍卖进行中 · 第 {{ round }} 场</span>
        <button v-if="isAdmin && phase === 'idle'" class="btn-ghost demo" @click="forceStart">立即开拍(演示)</button>
      </div>

      <!-- 本轮拍品队列 -->
      <div v-if="lots.length" class="queue">
        <div
          v-for="(lot, idx) in lots" :key="lot.id"
          class="queue-item" :class="{ current: idx === currentIndex, done: idx < currentIndex }"
          @click="openDetail(lot)"
        >
          <span class="q-idx">{{ idx + 1 }}</span>
          <span class="q-icon">{{ iconFor(lot.type) }}</span>
          <span class="q-name">{{ lot.name }}</span>
          <span class="chip grade-chip" :class="'grade-' + lot.grade">{{ lot.grade }}</span>
          <span v-if="idx < currentIndex" class="q-win">落槌 {{ lot.winner || '流拍' }}</span>
        </div>
      </div>

      <!-- 主拍卖台 -->
      <section class="stage glass">
        <template v-if="phase === 'bidding' && current">
          <div class="stage-head">
            <div class="stage-icon">{{ iconFor(current.type) }}</div>
            <div>
              <h2 class="grad-text">{{ current.name }}</h2>
              <div class="meta">
                <span class="chip">{{ current.type }}</span>
                <span class="chip" :class="'grade-' + current.grade">{{ current.grade }}品</span>
              </div>
            </div>
            <div class="countdown">
              <div class="cd-num">{{ seconds }}</div>
              <div class="cd-label">秒后落槌</div>
            </div>
          </div>

          <div class="cd-bar"><div class="cd-fill" :style="{ width: (seconds / 5 * 100) + '%' }"></div></div>

          <div class="price-row">
            <div class="price-box">
              <span>起拍价</span><b>{{ current.startPrice }} 灵石</b>
            </div>
            <div class="price-box hot">
              <span>当前最高</span><b class="grad-text">{{ currentBid }} 灵石</b>
            </div>
            <div class="price-box">
              <span>领先者</span><b>{{ leader || '暂无' }}</b>
            </div>
          </div>

          <!-- 加价按钮 -->
          <div class="bid-area">
            <p class="bid-hint">选择加价幅度（点击后立即出价，倒计时重置为 5 秒）</p>
            <div class="bid-buttons">
              <button v-for="inc in increments" :key="inc" class="bid-btn" :disabled="!connected || seconds<=0" @click="bid(inc)">
                +{{ inc }} <small>灵石</small>
              </button>
            </div>
            <p class="tip" :class="{ ok: bidTipOk }">{{ bidTip }}</p>
          </div>

          <!-- 出价记录 -->
          <div class="records">
            <h3>出价记录</h3>
            <div v-if="records.length" class="record-list">
              <div v-for="(r, i) in records" :key="i" class="record">
                <span class="r-user">✦ {{ r.bidder }}</span>
                <span class="r-inc">加价 {{ r.increment }}</span>
                <span class="r-total">→ {{ r.currentBid }} 灵石</span>
                <span class="r-time">{{ r.time }}</span>
              </div>
            </div>
            <div v-else class="empty-small">尚无出价，等你拔得头筹 ✧</div>
          </div>
        </template>

        <div v-else class="stage-idle">
          <div class="idle-orb">✦</div>
          <h2 class="grad-text">静待开拍</h2>
          <p>拍卖行每 10 分钟开启一场，开拍前 1 分钟将通知所有在线用户。</p>
          <p class="idle-sub">拍品来自系统中未拍卖的宝物，每次 5 件，按品级由低到高依次登场。</p>
        </div>
      </section>
    </main>

    <!-- 属性弹窗 -->
    <transition name="fade">
      <div v-if="detail" class="modal-mask" @click.self="detail = null">
        <div class="modal glass">
          <button class="modal-x" @click="detail = null">×</button>
          <div class="modal-icon">{{ iconFor(detail.type) }}</div>
          <h2 class="grad-text">{{ detail.name }}</h2>
          <div class="attr-list">
            <div class="attr"><span>品级</span><b :class="'grade-' + detail.grade">{{ detail.grade }}</b></div>
            <div class="attr"><span>类别</span><b>{{ detail.type }}</b></div>
            <div class="attr"><span>起拍价</span><b>{{ detail.startPrice ?? detail.price ?? '-' }} 灵石</b></div>
          </div>
          <p class="desc" style="text-align:center">{{ detail.description || '暂无描述。' }}</p>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onBeforeUnmount } from 'vue'
import Starfield from '../components/Starfield.vue'

const user = computed(() => { try { return JSON.parse(localStorage.getItem('sl_user') || '{}') } catch { return {} } })
const isAdmin = computed(() => user.value.permission === 0)
const stones = ref(user.value.stones ?? 0)

const online = ref(0)
const connected = ref(false)
const phase = ref('idle')           // idle | bidding
const notice = ref('')
const round = ref(0)
const lots = ref([])
const currentIndex = ref(0)
const current = computed(() => lots.value[currentIndex.value] || null)
const currentBid = ref(100)
const leader = ref('')
const seconds = ref(5)
const records = ref([])
const increments = [10, 50, 100, 500]
const bidTip = ref('')
const bidTipOk = ref(false)
const detail = ref(null)
const nextIn = ref(600)

let ws = null, timer = null, nextTimer = null

function iconFor(type) { return { 功法: '📜', 法宝: '🔮', 丹药: '💊' }[type] || '✦' }
function stamp() { const d = new Date(); return d.toTimeString().slice(0, 8) }

function connect() {
  const protocol = location.protocol === 'https:' ? 'wss' : 'ws'
  ws = new WebSocket(`${protocol}://${location.host}/ws/auction`)
  ws.onopen = () => {
    connected.value = true
    ws.send(JSON.stringify({ type: 'hello', username: user.value.username }))
  }
  ws.onmessage = e => {
    let m
    try { m = JSON.parse(e.data) } catch { return }
    switch (m.type) {
      case 'snapshot':
        online.value = m.online ?? 0
        if (typeof m.nextIn === 'number') nextIn.value = m.nextIn
        if (m.phase === 'bidding') {
          phase.value = 'bidding'; round.value = m.round || 0
          lots.value = m.lots || []; currentIndex.value = m.currentIndex || 0
          currentBid.value = m.currentBid || 100; leader.value = m.leader || ''
          seconds.value = m.seconds ?? 5; records.value = m.records || []
        }
        break
      case 'online': online.value = m.count; break
      case 'notice':
        notice.value = m.text
        setTimeout(() => { if (notice.value === m.text) notice.value = '' }, 60000)
        break
      case 'roundStart':
        phase.value = 'bidding'; round.value = m.round
        lots.value = m.lots; currentIndex.value = 0
        records.value = []; notice.value = ''
        break
      case 'lotStart':
        currentIndex.value = m.index
        currentBid.value = m.startPrice
        leader.value = ''; seconds.value = m.seconds ?? 5
        records.value = []
        break
      case 'bid':
        currentBid.value = m.currentBid
        leader.value = m.bidder
        seconds.value = m.seconds ?? 5
        records.value.unshift({ bidder: m.bidder, increment: m.increment, currentBid: m.currentBid, time: m.time || stamp() })
        // 只有本人出价才显示“你加价成功”，其他人只看到记录
        if (m.bidder === user.value.username) {
          bidTip.value = `出价成功！你加价 ${m.increment} 灵石`
          bidTipOk.value = true
        }
        break
      case 'bidReject':
        bidTip.value = m.message || '出价失败'; bidTipOk.value = false
        break
      case 'tick': seconds.value = m.seconds; break
      case 'lotEnd':
        if (lots.value[m.index]) {
          lots.value[m.index].winner = m.winner || '流拍'
          lots.value[m.index].finalPrice = m.finalPrice
        }
        leader.value = ''
        if (m.winner && m.winner === user.value.username) {
          bidTip.value = `恭喜！你以 ${m.finalPrice} 灵石拍得「${m.itemName}」`; bidTipOk.value = true
        }
        break
      case 'roundEnd':
        phase.value = 'idle'
        if (typeof m.nextIn === 'number') nextIn.value = m.nextIn
        break
      case 'stones': stones.value = m.value; break
    }
  }
  ws.onclose = () => {
    connected.value = false
    timer && clearInterval(timer)
    // 断线重连
    setTimeout(connect, 3000)
  }
  ws.onerror = () => {}
}

function bid(inc) {
  if (!connected.value || phase.value !== 'bidding') return
  ws.send(JSON.stringify({ type: 'bid', increment: inc }))
}
function forceStart() {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: 'forceStart' }))
}
function openDetail(lot) { detail.value = lot }

onMounted(() => {
  connect()
  nextTimer = setInterval(() => { if (phase.value === 'idle' && nextIn.value > 0) nextIn.value-- }, 1000)
})
onBeforeUnmount(() => {
  clearInterval(nextTimer)
  if (ws) ws.close()
})
</script>

<style scoped>
.content { max-width: 1000px; margin: 0 auto; padding: 24px 24px 60px; }
.logo { color: var(--star-gold); font-size: 20px; }

.status-bar { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 20px; margin-bottom: 20px; font-size: 14px; color: var(--ink-soft); }
.status-bar .notice { color: var(--star-gold); animation: pulse 1.4s infinite; }
.status-bar .demo { white-space: nowrap; }
@keyframes pulse { 50% { opacity: .5; } }

.queue { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 20px; }
.queue-item { display: flex; align-items: center; gap: 8px; padding: 8px 12px; border-radius: 12px; border: 1px solid var(--glass-line); background: rgba(255,255,255,.03); font-size: 13px; cursor: pointer; transition: all .2s; }
.queue-item.current { border-color: var(--star-cyan); background: rgba(169,240,255,.12); box-shadow: 0 0 20px rgba(169,240,255,.2); }
.queue-item.done { opacity: .5; }
.q-idx { color: var(--ink-soft); }
.q-icon { font-size: 18px; }
.q-name { font-weight: 600; }
.q-win { color: var(--star-gold); font-size: 12px; }

.stage { padding: 28px; }
.stage-head { display: flex; align-items: center; gap: 18px; }
.stage-icon { font-size: 56px; filter: drop-shadow(0 0 16px rgba(169,240,255,.5)); }
.stage-head h2 { margin: 0 0 8px; font-size: 26px; }
.meta { display: flex; gap: 8px; }
.countdown { margin-left: auto; text-align: center; }
.cd-num { font-size: 46px; font-weight: 700; color: var(--star-pink); line-height: 1; }
.cd-label { font-size: 12px; color: var(--ink-soft); }
.cd-bar { height: 6px; border-radius: 6px; background: rgba(255,255,255,.08); margin: 20px 0; overflow: hidden; }
.cd-fill { height: 100%; background: var(--accent); transition: width .3s linear; }

.price-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
.price-box { padding: 14px; border-radius: 12px; background: rgba(8,12,32,.5); border: 1px solid var(--glass-line); text-align: center; }
.price-box span { display: block; font-size: 12px; color: var(--ink-soft); margin-bottom: 6px; }
.price-box b { font-size: 17px; }
.price-box.hot { border-color: rgba(255,183,229,.4); }

.bid-area { margin-top: 22px; text-align: center; }
.bid-hint { color: var(--ink-soft); font-size: 13px; margin: 0 0 12px; }
.bid-buttons { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
.bid-btn { min-width: 110px; padding: 14px 18px; border-radius: 12px; border: 1px solid var(--glass-line); background: linear-gradient(135deg, rgba(169,240,255,.14), rgba(255,183,229,.14)); color: var(--ink); font-size: 18px; font-weight: 700; transition: transform .15s, box-shadow .15s; }
.bid-btn small { font-size: 11px; font-weight: 400; color: var(--ink-soft); }
.bid-btn:hover:not(:disabled) { transform: translateY(-3px); box-shadow: 0 8px 24px rgba(169,240,255,.25); }
.bid-btn:disabled { opacity: .45; cursor: not-allowed; }

.records { margin-top: 26px; border-top: 1px solid var(--glass-line); padding-top: 18px; }
.records h3 { font-size: 15px; margin: 0 0 12px; color: var(--star-cyan); }
.record-list { max-height: 180px; overflow-y: auto; }
.record { display: flex; gap: 14px; padding: 7px 4px; font-size: 13px; border-bottom: 1px dashed rgba(169,240,255,.1); }
.r-user { color: var(--star-cyan); min-width: 90px; }
.r-inc { color: var(--star-gold); }
.r-total { margin-left: auto; }
.r-time { color: var(--ink-soft); }
.empty-small { color: var(--ink-soft); font-size: 13px; padding: 16px 0; text-align: center; }

.stage-idle { text-align: center; padding: 30px 10px; }
.idle-orb { font-size: 64px; color: var(--star-cyan); filter: drop-shadow(0 0 24px rgba(169,240,255,.6)); animation: float 3s ease-in-out infinite; }
@keyframes float { 50% { transform: translateY(-12px); } }
.stage-idle h2 { font-size: 26px; margin: 12px 0; }
.stage-idle p { color: var(--ink-soft); margin: 6px 0; }
.idle-sub { font-size: 13px; opacity: .75; }

.grade-凡 { color: #b9c4d6; } .grade-灵 { color: #7fe3c0; } .grade-玄 { color: #7fb8ff; } .grade-地 { color: #c79bff; } .grade-天 { color: #ffcf7f; }
.modal-mask { position: fixed; inset: 0; z-index: 50; background: rgba(3,6,20,.7); display: flex; align-items: center; justify-content: center; padding: 20px; }
.modal { width: 100%; max-width: 400px; padding: 30px; text-align: center; position: relative; }
.modal-x { position: absolute; top: 12px; right: 16px; border: none; background: transparent; color: var(--ink-soft); font-size: 24px; }
.modal-icon { font-size: 56px; }
.modal h2 { margin: 8px 0 16px; }
.attr-list { margin: 16px 0; border-top: 1px solid var(--glass-line); border-bottom: 1px solid var(--glass-line); }
.attr { display: flex; justify-content: space-between; padding: 9px 4px; font-size: 14px; }
.attr span { color: var(--ink-soft); }
.fade-enter-active, .fade-leave-active { transition: opacity .2s; }
.fade-enter-from, .fade-leave-to { opacity: 0; }
</style>
