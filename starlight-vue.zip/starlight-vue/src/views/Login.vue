<template>
  <div class="screen auth-page">
    <Starfield />

    <div class="auth-wrap">
      <div class="brand">
        <div class="brand-mark">
          <svg viewBox="0 0 64 64" width="54" height="54" aria-hidden="true">
            <defs>
              <linearGradient id="bgg" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stop-color="#a9f0ff"/><stop offset="100%" stop-color="#ffb7e5"/>
              </linearGradient>
            </defs>
            <path fill="url(#bgg)" opacity=".95" d="M32 4c2 9 6 15 12 20-7 1-12 4-15 10-3-6-8-9-15-10 6-5 10-11 12-20 2 8 4 8 6 0z"/>
            <path fill="url(#bgg)" opacity=".6" d="M46 34c1.4 6 4 10 8 13-5 .6-8.6 2.6-10.6 6.6-2-4-5.6-6-10.6-6.6 4-3 6.6-7 8-13 1.4 5.4 3.4 5.4 5.2 0z"/>
            <circle cx="32" cy="26" r="2.6" fill="#fff"/>
          </svg>
        </div>
        <h1 class="brand-title grad-text">星海谣</h1>
        <p class="brand-sub">Starlight Bloom · 拾星者的夜航</p>
      </div>

      <div class="auth-card glass">
        <h2 class="card-title">欢迎归来 · 登 录</h2>
        <form class="auth-form" @submit.prevent="onLogin" autocomplete="off" novalidate>
          <div class="field">
            <span class="field-icon">✦</span>
            <input v-model="username" placeholder="星空账号 / 邮箱" maxlength="40">
          </div>
          <div class="field">
            <span class="field-icon">✧</span>
            <input :type="showPwd ? 'text' : 'password'" v-model="password" placeholder="登录密码" maxlength="40">
            <button type="button" class="eye" @click="showPwd = !showPwd">{{ showPwd ? '◌' : '◉' }}</button>
          </div>
          <p class="tip" :class="{ ok: tipOk }">{{ tip }}</p>
          <button type="submit" class="btn-main" :disabled="loading">{{ loading ? '启程中…' : '启 程 · 登录' }}</button>
        </form>
        <div class="foot">
          <span>还没有星舟？</span>
          <router-link to="/register">去注册 →</router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import api from '../api'
import Starfield from '../components/Starfield.vue'

const router = useRouter()
const username = ref('')
const password = ref('')
const showPwd = ref(false)
const tip = ref('')
const tipOk = ref(false)
const loading = ref(false)

async function onLogin() {
  tip.value = ''
  if (!username.value.trim() || !password.value) {
    tip.value = '请填写账号与密码'
    return
  }
  loading.value = true
  try {
    const res = await api.post('/auth/login', {
      username: username.value.trim(),
      password: password.value
    })
    localStorage.setItem('sl_token', res.token || '')
    localStorage.setItem('sl_user', JSON.stringify(res.user))
    tip.value = '登录成功，正驶入星海…'
    tipOk.value = true
    setTimeout(() => router.push('/home'), 400)
  } catch (e) {
    tip.value = e.message || '登录失败'
    tipOk.value = false
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.auth-page { display: flex; align-items: center; justify-content: center; padding: 40px 16px; }
.auth-wrap { width: 100%; max-width: 420px; }
.brand { text-align: center; margin-bottom: 26px; }
.brand-mark { display: inline-flex; filter: drop-shadow(0 0 18px rgba(169,240,255,.5)); }
.brand-title { font-size: 40px; letter-spacing: 8px; margin: 8px 0 2px; }
.brand-sub { color: var(--ink-soft); font-size: 13px; letter-spacing: 1px; margin: 0; }
.auth-card { padding: 30px 28px 24px; }
.card-title { text-align: center; font-size: 18px; letter-spacing: 3px; margin: 0 0 22px; font-weight: 600; }
.auth-form { display: flex; flex-direction: column; gap: 14px; }
.eye { border: none; background: transparent; color: var(--star-cyan); font-size: 16px; padding: 0 2px; }
.foot { margin-top: 18px; text-align: center; font-size: 13px; color: var(--ink-soft); }
.foot a { margin-left: 6px; }
</style>
