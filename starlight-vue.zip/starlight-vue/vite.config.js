import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// 后端地址：开发时通过代理转发，避免跨域。
// 前端 dev server 与后端都在本机，代理从 dev server 发出，用 127.0.0.1 即可稳定连通，
// 局域网其他设备访问前端页面时，请求仍由本机的 dev server 代理到后端。
const BACKEND = 'http://127.0.0.1:8081'

export default defineConfig({
  plugins: [vue()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    proxy: {
      '/api': { target: BACKEND, changeOrigin: true },
      '/ws': { target: 'ws://127.0.0.1:8081', ws: true, changeOrigin: true }
    }
  }
})
